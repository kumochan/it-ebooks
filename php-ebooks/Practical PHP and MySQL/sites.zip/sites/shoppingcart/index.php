<?php
	require("header.php");
?>
	<h1>Welcome!!</h1>
	Welcome to the <strong><?php echo $config_sitename; ?></strong> website. Click on one of the pages
	to explore the site. We have a wide range of different products available.
	
<?php

  require("footer.php");
?>
	
