<?php

$dbhost = "localhost";
$dbuser = "root";
$dbpassword = "";
$dbdatabase = "shoppingcart";

$config_basedir = "http://localhost/sites/shoppingcart/";

$config_sitename = "PerfectLand";

?>
