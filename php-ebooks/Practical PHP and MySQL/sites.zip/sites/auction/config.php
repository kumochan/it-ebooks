<?php

$dbhost = "localhost";
$dbuser = "root";
$dbpassword = "";
$dbdatabase = "auction";

// Add your name below
$config_admin = "Jono Bacon";
$config_adminemail = "jono AT jonobacon DOT org";

// Add the location of your forums below
$config_basedir = "http://localhost/sites/auction/";

// The currency used on the auction
$config_currency = "$";
?>
