<p>&copy; <?php echo "<a href='mailto:" . $config_adminemail . "'>" .$config_admin . "</a>"; ?></p>
</div>
</div>


</body>
</html>