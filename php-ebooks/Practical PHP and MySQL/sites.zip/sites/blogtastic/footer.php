
<p>&copy; <?php echo $config_author; ?></p>
</div>
</div>
</body>
</html>