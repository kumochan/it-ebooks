<?php

$dbhost = "localhost";
$dbuser = "root";
$dbpassword = "";
$dbdatabase = "blogtastic";

// Add your blog name below
$config_blogname = "Funny old world";

// Add your name below
$config_author = "Jono Bacon";

// Add the location of your blog below
$config_basedir = "http://127.0.0.1/sites/blogtastic/";

?>
