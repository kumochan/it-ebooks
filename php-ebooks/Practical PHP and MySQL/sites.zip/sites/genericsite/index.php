<?php
	require("header.php");
?>
	<h1>Welcome!!</h1>
	<p>
	Welcome to my website!
	</p>
	<p>
	On this website, you can find a load of information about me and the different things I am interested
	in. You can also find out about my <i>superb</i> dogs and what they like to do.
	</p>
	<p>
	On this website you can find out about:
	<ul>
		<li>My interests</li>
		<li>My dogs</li>
		<li>My website</li>
	</ul>
	</p>
<?php

  require("footer.php");
?>
	
