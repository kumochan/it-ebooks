<?php

$config_sitename = "Jinny's Homepage";

$config_basedir = "http://localhost/sites/genericsite/";

?>
