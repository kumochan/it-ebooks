<?php

	require("header.php");
?>
	<h1>Technical Details</h1>
	<p>
	Nisl, consequat consequat, odio praesent exerci delenit ut duis accumsan delenit nulla suscipit. Nisl tincidunt veniam enim dolore. Quis blandit, molestie, lobortis, ut illum, eum minim te dolor aliquip at magna odio et. Feugait ea augue dolore delenit ea nulla hendrerit exerci feugiat eum dolore accumsan feugiat blandit. Tation, duis autem, illum dolore dolore, autem eros elit lobortis vero in facilisi dignissim vero, ullamcorper nostrud iriure ipsum. Eu, volutpat ea wisi eum nibh delenit wisi velit duis vulputate et ut suscipit amet consectetuer erat enim. Qui veniam in molestie dolore veniam ullamcorper eum. Et ut, quis ad te aliquip nibh, consequat nisl feugait consequat iriure qui aliquam ad ex ipsum. Luptatum dignissim accumsan commodo, commodo laoreet eu augue nulla facilisi in velit nulla quis te. Nostrud nulla praesent.
	</p>

	<table cellspacing="0" cellpadding="10">
		<tr>
			<th>Tool</th>
			<th>Version</th>
			<th>Description</th>
		</tr>
		<tr>
			<td>PHP</td>
			<td>4.x and 5.x</td>
			<td>Scripting language for web applications</td>
		</tr>
		<tr>
			<td>MySQL</td>
			<td>4.x</td>
			<td>Powerful database system</td>
		</tr>
	</table>
<?php
	require("footer.php");
?>