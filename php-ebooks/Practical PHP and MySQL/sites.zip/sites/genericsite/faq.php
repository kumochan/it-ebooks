<?php

	require("header.php");
?>
	<a name="top"></a>
	<h1>Frequently Asked Questions</h1>
	<ul>
		<li><a href="#1">Ipsum, eu consectetuer, praesent ad, lobortis veniam.</a></li>
		<li><a href="#2">Autem illum suscipit volutpat exerci adipiscing in lorem.</a></li>
		<li><a href="#3">Luptatum suscipit</a></li>
		<li><a href="#4">Qui veniam accumsan tincidunt veniam</a></li>
		<li><a href="#5">At iriure amet et odio</a></li>
	</ul>

<a name="1"></a>
<h2>Ipsum, eu consectetuer, praesent ad, lobortis veniam</h2>
<p>
Ipsum, eu consectetuer, praesent ad, lobortis veniam. Vulputate laoreet dignissim, veniam dolor. Dolor ad in odio aliquip ea diam augue. Wisi delenit, tation nulla dolore exerci. Molestie adipiscing in et velit praesent. Dolor autem velit, dolore, dignissim te blandit eros. Wisi lobortis nisl hendrerit exerci dignissim vel augue facilisi iriure. Consequat nulla praesent, lorem augue eum duis ex augue. Vulputate suscipit vulputate ut aliquip ad consectetuer ut eros.
</p>
<p><a href="#top">Back to the top</a></p>

<a name="2"></a>
<h2>Autem illum suscipit volutpat exerci adipiscing in lorem.</h2>
<p>
Autem illum suscipit volutpat exerci adipiscing in lorem. Nulla nostrud lobortis tation ullamcorper. Eum tation vel feugait euismod dignissim feugiat, iusto iriure in commodo illum consequat dolor eros vel luptatum minim. Accumsan, ullamcorper iriure ut diam aliquam consequat at nisl adipiscing praesent. Exerci augue duis ad ex aliquam, eros, dolore consequat vel esse esse euismod dolor commodo ad, tation qui quis dolore. Dolore velit duis, esse et vel eros sit dolor feugait esse aliquip autem ut commodo dignissim, ut eros quis. Ut at consectetuer laoreet aliquip eu tation dolor dignissim ex nisl. In et lobortis feugiat facilisis laoreet luptatum commodo hendrerit in sed, vel aliquip facilisi in, et enim duis et. Magna praesent in minim velit facilisis, facilisi autem augue hendrerit lobortis. At, feugait aliquip. Consequat te ut iusto facilisis eu. Vulputate consequat aliquam nulla nibh nostrud, tincidunt aliquam aliquip, dolore dolor, aliquip consequat sit feugait augue.
</p>
<p><a href="#top">Back to the top</a></p>

<a name="3"></a>
<h2>Luptatum suscipit</h2>
<p>
Luptatum suscipit, qui in elit odio lobortis consequat nulla enim consequat ea blandit, ex consequat wisi erat, luptatum. Iusto, velit nonummy nostrud delenit ut dolor accumsan tincidunt autem suscipit duis nisl, veniam enim dolore te nonummy, ut suscipit. Laoreet ea eum odio magna wisi ut eum ea tation quis facilisi. Ullamcorper ut illum aliquip feugiat feugait hendrerit. Augue volutpat veniam commodo amet duis blandit odio, duis duis magna nulla dolore, at ipsum velit. Vulputate vero iusto nulla elit ipsum, augue, blandit iriure iriure feugiat, consequat facilisi accumsan consectetuer suscipit dolore. Esse blandit enim, nibh amet illum molestie hendrerit, minim vero eum. Commodo minim in ut dolore dolor delenit et molestie sed, feugiat illum nostrud exerci vel, hendrerit accumsan, exerci. Aliquip duis volutpat vulputate ut odio quis ut nisl. Eum et autem feugait nulla consequat sit, minim esse duis ad diam vel dignissim. Feugiat augue praesent iriure iriure ut. Eum, facilisi, iriure et, vel aliquip accumsan tincidunt, dolor praesent et te augue hendrerit in vero iusto sit.
</p>
<p><a href="#top">Back to the top</a></p>

<a name="4"></a>
<h2>Qui veniam accumsan tincidunt veniam</h2>
<p>
Qui veniam accumsan tincidunt veniam elit molestie sed vel ullamcorper duis duis ipsum, ut nostrud delenit feugait, nulla dolore. Luptatum feugiat consequat accumsan duis magna eum molestie delenit ut, odio duis minim delenit, blandit nostrud. Lobortis blandit ut dolore consequat. Dolor duis amet minim, in nulla luptatum feugiat veniam enim at consequat wisi hendrerit in amet vero. Enim, ex ea, feugait suscipit minim qui ea illum luptatum accumsan illum nulla, enim. Facilisis ut dolor nibh qui ullamcorper et facilisi accumsan, blandit odio odio magna iusto nonummy. Consectetuer nostrud minim delenit wisi facilisis et vel blandit illum at feugait feugiat nostrud duis ut in. Dolor ex minim nisl illum dolore vulputate wisi, elit euismod tation nonummy consequat molestie nisl feugait luptatum dignissim. Consequat iusto odio nostrud at illum, consequat dolor amet vel luptatum, amet et ullamcorper odio ut qui feugait.
</p>
<p><a href="#top">Back to the top</a></p>

<a name="5"></a>
<h2>At iriure amet et odio</h2>
<p>
At iriure amet et odio exerci te nulla velit aliquip dignissim ut esse, volutpat, magna blandit praesent hendrerit, sed. Sit praesent suscipit facilisi vero nibh. Delenit exerci, commodo suscipit ad ut augue, augue sed vulputate tation augue. Lorem autem et ut facilisi lobortis autem ut accumsan vero te ut nibh consequat blandit. Dolore dolore iriure in dolore ad delenit ipsum commodo dignissim accumsan commodo commodo molestie eu augue nulla. Dolor veniam velit nulla accumsan te, consectetuer nulla praesent dignissim autem nulla dolore ea te eros sit exerci vel minim. Iriure eum diam dolor duis luptatum dolor in wisi et ut iusto adipiscing illum. Dolor iusto ut ad, euismod adipiscing nulla duis, vulputate vulputate, et odio minim qui nonummy ex at.
</p>
<p><a href="#top">Back to the top</a></p>

<?php
	require("footer.php");
?>