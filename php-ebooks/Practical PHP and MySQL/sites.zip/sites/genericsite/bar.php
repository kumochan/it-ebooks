<h1>Mug Shot</h1>
<img src="photo.jpg">

<h1>Details</h1>
<ul>
	<li>I am a workaholic</li>
	<li>I have two dogs called Banger and Frankie</li>
	<li>My favorite colour is blue</li>
</ul>
