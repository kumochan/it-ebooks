<?php

require("config.php");

session_start();

session_unregister('SESS_ADMIN');
session_unregister('SESS_ADMINUSER');
session_unregister('SESS_ADMINID');

header("Location: " . $config_basedir);

?>