<?php

    $dbhost = "localhost";
    $dbuser ="root";
    $dbpassword = "";
    $dbdatabase = "faq";

    $config_basedir = "http://localhost/sites/faq/";

    $config_sitename = "You ask the questions";
?>
