<html>
<head>
<title>Welcome!</title>
</head>
<body>
<h1>Welcome to the book!</h1>
<hr>
To access the projects, click the links below:

<ul>
	<li><strong>Chapter 4</strong> - <a href="http://localhost/sites/blogtastic/">Blog</a></li>
	<li><strong>Chapter 5</strong> - <a href="http://localhost/sites/forums/">Forums</a></li>
	<li><strong>Chapter 6</strong> - <a href="http://localhost/sites/shoppingcart/">Shopping Cart</a></li>
	<li><strong>Chapter 7</strong> - <a href="http://localhost/sites/auction/">Auction</a></li>
	<li><strong>Chapter 8</strong> - <a href="http://localhost/sites/simplecal/">Calendar</a></li>
	<li><strong>Chapter 9</strong> - <a href="http://localhost/sites/faq/">FAQ</a></li>
	<li><strong>Chapter 10</strong> - <a href="http://localhost/sites/homeproject/">Reusable Component</a> (<a 
href="http://localhost/sites/genericwithprojects/">Site with embedded component</a>)</li>
	<li><strong>Chapter 11</strong> - <a href="http://localhost/sites/news/">News</a></li>
	<li><strong>Appendix</strong> - <a href="http://localhost/sites/genericsite/">Generic Site</a></li>	
</ul>
<hr>
All projects are licensed under the LGPL. All projects written by <a href="http://www.jonobacon.org">Jono Bacon</a>.
</body>
</html>
