<?php

$dbhost = "localhost";
$dbuser = "root";
$dbpassword = "";
$dbdatabase = "simplecal";

$config_name = "James Hillchin's Calendar";

$config_basedir = "http://localhost/sites/simplecal/";

?>
