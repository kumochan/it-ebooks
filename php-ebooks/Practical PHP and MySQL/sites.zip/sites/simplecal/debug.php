<?php

function debug_box($text) {
	echo "<script>alert('" . $text . "');</script>";
}

function debug_shout() {
	echo "<script>alert('Shout!');</script>";
}


?>