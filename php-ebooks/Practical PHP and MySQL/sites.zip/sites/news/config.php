<?php

$dbhost = "localhost";
$dbuser = "root";
$dbpassword = "";
$dbdatabase = "news";

$config_basedir = "http://localhost/sites/news/";

?>
