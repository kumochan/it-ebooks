<h1>Options</h1>
<ul>
<li><a href="index.php">Home</a></li>
<li><a href="index.php?func=download">Download</a></li>
<li><a href="index.php?func=screenshots">Screenshots</a></li>
</ul>