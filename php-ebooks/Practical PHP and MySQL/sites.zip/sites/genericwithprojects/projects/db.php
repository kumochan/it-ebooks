<?php

	require("phphomeprojectconfig.php");

	$db = mysql_connect($dbhost, $dbuser, $dbpassword);
	mysql_select_db($dbdatabase, $db);

?>