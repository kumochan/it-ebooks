<?php

$dbhost = "localhost";
$dbuser = "root";
$dbpassword = "";
$dbdatabase = "phphomeproject";

$config_headerfile = "/ot/lampp/htdocs/sites/genericwithprojects/header.php";
$config_footerfile = "/ot/lampp/htdocs/sites/genericwithprojects/footer.php";

$config_projecturl = "http://localhost/sites/genericwithprojects/projects/";
$config_projectdir = "/opt/lampp/htdocs/sites/genericwithprojects/projects/";


$config_projectadminbasedir = "http://localhost/sites/genericwithprojects/projects/admin/";
$config_projectadminfilename = "admin.php";

$config_projectscreenshotthumbsize = 300;
?>
